import speedtest
import time

# Function to run the internet speed test
def test_speed():
    try:
        st = speedtest.Speedtest()

        # Perform download and upload speed tests
        print("Finding best server...")
        st.get_best_server()  # Get the best server
        print("Testing download speed...")
        download_speed = st.download() / 1_000_000  # Convert to Mbps
        print("Testing upload speed...")
        upload_speed = st.upload() / 1_000_000  # Convert to Mbps

        # Print the results
        print(f"Download Speed: {download_speed:.2f} Mbps")
        print(f"Upload Speed: {upload_speed:.2f} Mbps")

        return download_speed, upload_speed

    except Exception as e:
        print(f"An error occurred while testing speed: {e}")
        return None, None

# Main function that gets called when the script starts
def main():
    
    # Variables to track peak and lowest speeds
    peak_download = 0
    lowest_download = float('inf')
    peak_upload = 0
    lowest_upload = float('inf')

    # Run the speed test multiple times for better results
    for _ in range(3):  # You can adjust the number of tests
        download_speed, upload_speed = test_speed()

        if download_speed is not None and upload_speed is not None:
            # Update peak and lowest speeds
            peak_download = max(peak_download, download_speed)
            lowest_download = min(lowest_download, download_speed)
            peak_upload = max(peak_upload, upload_speed)
            lowest_upload = min(lowest_upload, upload_speed)

            # Provide feedback based on download speed
            if download_speed < 5:
                print("Your internet is very slow. Example: Struggling to load basic web pages or send emails.")
            elif 5 <= download_speed < 10:
                print("Your internet is slow. Example: Video calls may lag, and streaming may buffer.")
            elif 10 <= download_speed < 20:
                print("Your internet is moderately slow. Example: Streaming in standard definition is possible, but HD may buffer.")
            elif 20 <= download_speed < 50:
                print("Your internet is average. Example: Streaming HD videos and online gaming are possible with some limitations.")
            elif 50 <= download_speed < 100:
                print("Your internet is fast. Example: Seamless streaming of HD content and smooth online gaming.")
            elif 100 <= download_speed < 200:
                print("Your internet is very fast. Example: Multiple devices can stream 4K content simultaneously without interruption.")
            elif 200 <= download_speed < 500:
                print("Your internet is super fast! Example: Uploading and downloading large files happens in seconds, and online gaming is a breeze.")
            elif 500 <= download_speed < 1000:
                print("Your internet is lightning fast! Example: You can handle intense online gaming sessions, video conferencing, and multiple 4K streams without a hitch.")
            else:
                print("Your internet is blazing fast! Example: 8K streaming, heavy online gaming, and downloading huge files in moments are all effortless.")

    # Print the peak and lowest speeds
    print(f"\nPeak Download Speed: {peak_download:.2f} Mbps")
    print(f"Lowest Download Speed: {lowest_download:.2f} Mbps")
    print(f"Peak Upload Speed: {peak_upload:.2f} Mbps")
    print(f"Lowest Upload Speed: {lowest_upload:.2f} Mbps")

    # Wait 999 seconds before closing
    print("Waiting 999 seconds before closing...")
    time.sleep(999)

if __name__ == "__main__":
    print("Script started!")
    main()
